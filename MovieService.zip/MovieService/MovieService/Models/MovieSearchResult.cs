﻿using System.Collections.Generic;

namespace MovieService.Models
{
    public class MovieSearchResult
    {
        public List<Movie> Search { get; set; }
        public string TotalResults { get; set; }
    }
}
